# yandex_cloud_elk Collection

## Описание
Коллекция содержит пользовательский модуль Ansible для создания текстовых файлов на удаленных хостах с поддержкой идемпотентности.

## Модули

### my_own_module
Создает текстовый файл с указанным содержимым.

#### Параметры
| Параметр | Обязательный | Тип | По умолчанию | Описание |
|----------|--------------|-----|--------------|----------|
| path | да | str | - | Путь к файлу на удаленном хосте |
| content | да | str | - | Содержимое файла |
| mode | нет | str | 0644 | Права доступа к файлу (в восьмеричном формате) |

#### Примеры использования

```yaml
- name: Создать файл с приветствием
  my_own_namespace.yandex_cloud_elk.my_own_module:
    path: /tmp/hello.txt
    content: "Hello, World!"

- name: Создать файл с произвольными правами
  my_own_namespace.yandex_cloud_elk.my_own_module:
    path: /etc/myapp/config.ini
    content: |
      [settings]
      debug=true
      log_level=info
    mode: "0600"

Возвращаемые значения
Значение	Тип	Описание
changed	bool	Были ли изменения (файл создан или обновлен)
path	str	Путь к созданному/обновленному файлу
Роли
create_file

Роль-обертка для модуля my_own_module с настраиваемыми параметрами по умолчанию.
Переменные роли
Переменная	Тип	По умолчанию	Описание
file_path	str	/tmp/default_ansible_file.txt	Путь к файлу
file_content	str	"Default content from role"	Содержимое файла
file_mode	str	"0644"	Права доступа к файлу
Пример использования роли
yaml

- name: Использование роли create_file
  hosts: webservers
  vars:
    file_path: /var/www/config.txt
    file_content: |
      server_name=example.com
      debug=false
    file_mode: "0644"
  roles:
    - create_file

Установка
Из локального архива
bash

ansible-galaxy collection install my_own_namespace-yandex_cloud_elk-1.0.0.tar.gz

Из репозитория GitHub
bash

ansible-galaxy collection install git+https://github.com/YOUR_USERNAME/my_own_collection.git

Тестирование
Локальное тестирование модуля
bash

cd /home/vagrant/my_own_namespace/yandex_cloud_elk
python plugins/modules/my_own_module.py test_args.json

Тестирование с playbook
bash

ansible-playbook playbook_with_role.yml

Лицензия

GPL-3.0-or-later
Авторы

Your Name (@yourgithub)
