#!/usr/bin/python
from ansible.module_utils.basic import AnsibleModule
import os

def main():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='str', required=True),
            content=dict(type='str', required=True),
            mode=dict(type='str', required=False, default='0644')
        ),
        supports_check_mode=True
    )
    
    path = module.params['path']
    content = module.params['content']
    mode = module.params['mode']
    
    changed = False
    
    if not os.path.exists(path):
        changed = True
    else:
        with open(path, 'r') as f:
            if f.read() != content:
                changed = True
    
    if module.check_mode:
        module.exit_json(changed=changed, path=path)
    
    if changed:
        directory = os.path.dirname(path)
        if directory and not os.path.exists(directory):
            os.makedirs(directory)
        with open(path, 'w') as f:
            f.write(content)
        os.chmod(path, int(mode, 8))
    
    module.exit_json(changed=changed, path=path)

if __name__ == '__main__':
    main()
